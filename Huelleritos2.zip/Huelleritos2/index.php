<?php
  require_once 'Controlador/conexion.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Huelleritos</title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<!-- cargar estilos  -->
	<link href="Vista/css/estilos.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</head>

<body>

	<!-- Menu -->	
	<div class="container-fluid">
		<div class="container-fluid color1">
			<br><br>
		</div>
		<nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
			<div class="container-fluid">
				
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">   
						<i class="fas fa-bars" style="color: black; font-size:28px;"></i>
					</span>
				</button>

				<div class="collapse navbar-collapse" id="navbarTogglerDemo01">


					<a class="navbar-brand" href="index.html"></a>
					<ul class="navbar-nav mx-auto mt-2 mt-lg-0">
						<a class="navbar-brand" href="#">
							<img src="Vista/img/logo.png" width="50" height="50" alt="">
						</a>
						<li class="nav-item active">
							<a class="nav-link" href="index.html">INICIO<span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="Vista/html/Huelleritos.html">HUELLERITOS</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" href="Vista/html/Adopta.html">ADOPTA</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" href="Vista/html/Apadrinar.html">APADRINA</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" href="Vista/html/Hogar_Paso.html">HOGAR DE PASO</a>
						</li>
						
						<li class="nav-item">
							<a class="nav-link" href="Vista/html/La_Fundacion.html">LA FUNDACION</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="Vista/html/Noticias.html">NOTICIAS</a>
						</li>
						<li class="nav-item">
							<a href="Vista/html/Dona_aqui.html"><button type="button" class="btn btn-secondary">DONA AQUI <i class="fab fas fa-paw fa-1x" style="color: #FFFFFF;"></i></button></a>
						</li>

						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="#">Configuracion</a>
								<a class="dropdown-item" href="#">Mi Perfil</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="../index.html">Salir</a>
							</div>
						</li>
					</ul>

				</div>
			</div>
		</nav>
	</div>
	<hr class="potaxio">
	<br>

	<!-- Carrusel de imagenes -->
	<div class="container-fluid">
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
		</ol>
		<div class="carousel-inner">
			<div class="carousel-item active">
				<img class="d-block w-100" src="Vista/img/slider1.jpg" alt="First slide">
			</div>
			<div class="carousel-item">
				<img class="d-block w-100" src="Vista/img/slider2.jpg" alt="Second slide">
			</div>
			<div class="carousel-item">
				<img class="d-block w-100" src="Vista/img/slider3.jpg" alt="Third slide">
			</div>
		</div>
		<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Anterior</span>
		</a>
		<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Siguiente</span>
		</a>
		</div>
	</div>
	<br><br><br>

	<!-- Carrusel Huelleritos en adopcion -->
	<h1 class="centro">Huelleritos en adopcion<hr></h1><br>

	<div class="container">
		<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner">

				<div class="carousel-item active">
					

					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.sommelierdecafe.com/2019/wp-content/uploads/2019/03/Perro-de-frente-800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2019/04/03/04-australian-shepherd_af05aa09_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2019/06/18/_3a525832_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

					</div>
				</div>

				<div class="carousel-item">
					

					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2018/02/27/perros2_56d11542_800x800.JPG" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2019/06/13/_db0c0e4b_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2019/02/25/de-tal-palo-tal-astilla_2fc89eb0_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="carousel-item">
					

					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2020/02/11/los-beneficios-de-la-interaccion-entre-dueno-y-mascota-van-en-ambas-direcciones-la-mente-de-las-mascotas-tambien-se-favorece-de-los-lazos-estrechos-con-su-dueno_1705cb69_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="http://cdn.shopify.com/s/files/1/0740/0383/articles/heces_de_perros_en_las_calles_1024x1024.png?v=1593220661" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://www.nationalgeographic.com.es/medio/2019/09/09/bull-dog-ingles_043b09e1_800x800.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Edad del animal</h5>
									<h4>Nombre del animal</h4>
									<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									<a href="#" class="btn btn-dark">Conoce Mas</a>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>

			<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>
	<br>

	<!-- Noticias -->
	<h1 class="centro">Noticias<hr></h1><br>

	<div class="container">
		<div id="carouselExampleControl" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner">

				<div class="carousel-item active">

					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

					</div>
				</div>

				<div class="carousel-item">
					
					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="carousel-item">				

					<div class="row">
						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="card centro">
								<img class="card-img-top" src="https://thumbs.dreamstime.com/b/breaking-news-live-abstract-red-blue-banner-white-text-dark-background-technology-business-tv-vector-illustration-105537370.jpg" alt="Card image cap">
								<div class="card-body">
									<h5 class="card-title">Titulo de la Noticia</h5>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>

			<a class="carousel-control-prev" href="#carouselExampleControl" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleControl" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>
	<br><br>

	<!-- Instagram -->
	<h1 class="centro">Nuestro Instagram<hr></h1><br>
		<div class="container">
			<div>
				<script src="https://apps.elfsight.com/p/platform.js" defer></script>
				<div class="elfsight-app-c41bab9c-88c6-4408-a5a6-62b7283c0e80"></div>
			</div>
		</div>
		
	<!-- PIE DE PAGINA -->
	<footer class="morado centro">
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-2 izquierda">
				
				<h3>CONTACTANOS</h3>
				<p>Telefono: <br>3001112223<br>
					Correo electronico:<br>Huelleritos@gmail.com</p>

				</div>
				<div class="col-sm-2 izquierda">
					<h3>SIGUENOS EN</h3>

					<a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-1x" style="color: #FD427E;"> HuelleritosCucuta</i></a><br>

					<a href="https://es-la.facebook.com/" target="_blank"><i class="fab fa-facebook-square fa-1x" style="color: #3b5999;"> HuelleritosCucuta</i></a><br>

					<a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-1x" style="color: #55acee;"> HuelleritosCucuta</i></a><br>
				</div>
				<div class="col-sm-4"></div>
			</div>
			<div class="container-fluid blanco">
				<div class="row">
					<div class="col-sm-10 izquierda">© 2021 Huelleritos Cucuta</div>
					<div class="col-sm-1">Privacy Policy</div>
					<div class="col-sm-1">Terms of service</div>
				</div>
			</div>	
		</footer>

	<script src="js/javascript.js"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>