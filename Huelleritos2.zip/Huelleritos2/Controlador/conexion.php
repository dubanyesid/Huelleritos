<?php

// Creacion de conexion al servidor
try {
    /* CONEXION CON EL SERVIDOR LOCAL PC */
    $conexion = mysqli_connect("db4free.net","admin_3117111061","Jungilwoo9","huelleritos_123");
   // Error
} catch (PDOException $error) {
    echo 'Connection error: ' . $error->getMessage();
}
?>

